#/bin/sh
# ChangeLog:
#    * Alterada data de comparacao para segundos
###############################################################################


################################################################
# Declaracao de variaveis globais no shell
################################################################

# Exportacao da Variavel com nome do Programa
export BBPROG="orabkp.sh"

# Exportacao da variavel test
export TEST="bkp"

# Exportacao da variavel BBHOME
#export BBHOME="/home/bb/bb"

# Definitions and Temporary locations
. $BBHOME/etc/bbdef.sh          # INCLUDE STANDARD DEFINITIONS
export TEMPFILE=$BBTMP/orabkp.$$
export TEMPFILE_OUTPUT=$BBTMP/orabkp.output.$$

export STATUS_GERAL="green"
export ORACLE_SIDS_PROBLEMA=""
export COLOR="green"

echo " "  > $TEMPFILE_OUTPUT   # Zera arquivo temporario
export LINE=""
export SPACER="   "

#Diretorio dos Logs de Backup
DirBkpLog="/backup/bkporacle/log" 

HorasAlerta=12
HorasErro=24

#############################
# Variaveis de controle da execucao
############################
DirChkBkp="/backup/quick/chkbkp"                # Diretorio de Checagem dos Backups


################################################################
# Fim Declaracao de variaveis globais no shell
################################################################


################################################################
# Inicio de algumas validacoes
################################################################


# Checa se BBHOME foi setado e Diretorios existem
if [ "$BBHOME" = "" ]
then
  echo "orabkp.sh: BBHOME não esta setado..."
  exit 1
fi

if [ ! -d "$BBHOME" ]
then
  echo "orabkp.sh: Diretorio invalido (BBHOME=$BBHOME)"
  exit 1
fi

if [ ! "$BBTMP" ]
then
  # Executa bbdef
  . $BBHOME/etc/bbdef.sh
fi

################################################################
# Fim de algumas validacoes
################################################################

# Tem como objetivo gerar o status final de exportacao da pagina
GeraStatusFinal ()
{
  if `cat "$TEMPFILE_OUTPUT" | grep  \&red | grep -v grep  1>> /dev/null 2>>/dev/null`
  then
    STATUS_GERAL="red"
  elif  `cat "$TEMPFILE_OUTPUT" | grep  \&yellow | grep -v grep 1>> /dev/null 2>>/dev/null`
  then
    STATUS_GERAL="yellow"
  elif `cat "$TEMPFILE_OUTPUT" | grep \&green | grep -v grep 1>> /dev/null 2>>/dev/null`
  then
    STATUS_GERAL="green"
fi
}


#Busca a palavra erro ou a palavra warning los arquivos de log
busca_erro ()
{
  
  if [ `cat "$1" | grep -i erro | wc -l` -gt 0 ]
  then
    COLOR="red"
    StrResult=" &red Backup da instance $AUX_DBNAME com mensagens de erro no Log."
  elif [ `cat "$1" | grep -i warning | wc -l` -gt 0  ]
  then
    COLOR="yellow"
    StrResult="&yellow Backup da instance $AUX_DBNAME contem alertas no arquivo de Log."
  else
    StrResult="Nao foram encontrados problemas nos Logs de Backup."
  fi
  echo $StrResult >> $TEMPFILE_OUTPUT
  
}

#Recupera o passo a passo executado no backup
pega_Sequencia ()
{
  echo "Log File: $1" >> $TEMPFILE_OUTPUT
  cat "$1" | grep "\[" | while read LINE
  do
    echo $LINE >> $TEMPFILE_OUTPUT
  done
}

#Recupera o ultimo arquivo de backup tanto do backup online quanto do archive
pega_ultArq ()
{
  if [ "$1" = "full" ]
  then 
    StrFile=`ls -rt $DirBkpLog/*.log |grep -i ${AUX_DBNAME}| grep -v archives | tail -n 1`
  elif [ "$1" = "archive" ]
  then
    StrFile=`ls -rt $DirBkpLog/*.log |grep -i ${AUX_DBNAME} | grep archives | tail -n 1`
  fi
}

#Verifica status do backup online e dos arquivos de log de backup
verifica_online ()
{

  if [ -f "$ArqBkpConcluido" -a -f "$ArqBkpUltExec" ]
  then
    DataConclusao=`cat "$ArqBkpConcluido"`
    DataUltExec=`cat "$ArqBkpUltExec"`
    pega_ultArq "full"
    if [ 0 -lt `expr ${DataConclusao} - ${DataUltExec}` ]
    then 
      if [ -f "$StrFile" ] 
      then 
        busca_erro "$StrFile"
        echo "Passos da Execucao Backup Online" >> $TEMPFILE_OUTPUT
        pega_Sequencia "$StrFile"
      else
        echo "&red Nenhum arquivo de log do Backup Online Encontrado!" >> $TEMPFILE_OUTPUT
      fi  
      
    else

      COLOR="red"
      echo "&red Data da Ultima Execucao e Data da Execucao Atual nao coincidem. Provavel erro no Backup.
      Favor verificar!" >> $TEMPFILE_OUTPUT
      echo " Passos da Execucao Backup Online" >> $TEMPFILE_OUTPUT

      [ -f "$StrFile" ] && pega_Sequencia "$StrFile"
    fi
  elif [ -f "$ArqBkpAndamento" ]
  then
    PID=`cat "$ArqBkpAndamento" | grep -i "processo" | cut -d " " -f 2`
    if [ `ps auxww | grep -v grep | grep $PID | wc -l` -gt 0 ]
    then
    DataInicio=`cat "$ArqBkpAndamento" | grep -i data | cut -d " " -f 2`
      if [ `expr \`date '+%s'\` - $DataInicio` -gt `expr $HorasAlerta \* 60 \* 60` ]
      then 
        COLOR="yellow"
        echo "&yellow Processo de Backup esta executando a mais de $HorasAlerta Horas" >> $TEMPFILE_OUTPUT
      elif [ `expr \`date '+%s'\` - $DataInicio` -gt `expr $HorasErro \* 60 \* 60` ]
      then
        COLOR="red"
        echo "&red Processo de Backup esta executando a mais de $HorasErro Horas" >> $TEMPFILE_OUTPUT
      else
        echo "&green Processo de Backup esta executando ..." >> $TEMPFILE_OUTPUT
      fi
    else
      COLOR="red"
      echo "&red O backup ainda esta em andamento, mas o processo do S.O. nao esta em execucao. Provavel erro. Favor Verificar!" >> $TEMPFILE_OUTPUT
    fi
  else
    echo "&red Nenhum arquivo de controle encontrado para Instance ${AUX_DBNAME}!" >> $TEMPFILE_OUTPUT
  fi
  
}

#Verifica status do backup intermediario (archives) e dos arquivos de log de backup
verifica_Intermediario ()
{
  unset StrFile 
  pega_ultArq "archive"

  if [ -f "$StrFile" ] 
  then 
    busca_erro "$StrFile"
    echo "Passos da Execucao Backup Intermediario"  >> $TEMPFILE_OUTPUT
    pega_Sequencia "$StrFile"
  else
    echo "&red Nenhum arquivo de log do Backup Archive Encontrado para Instance ${AUX_DBNAME}!" >> $TEMPFILE_OUTPUT
  fi
  
}





#################################################################################################################
#  INICIO DOS TESTES
#################################################################################################################

# Relacao de SIDS a serem monitoradas
# Deverarao ser cadastrados os devidos parametros para cada SID
# Ex: ORACLE_SIDS="db1 db2 db3"; export ORACLE_SIDS
export ORACLE_SIDS=`cat ${BBHOME}/etc/ora-sid.sh`


#START
for DB in $ORACLE_SIDS
do
  echo "************************************************************************************" >> $TEMPFILE_OUTPUT
  echo "                       INFORMACOES SOBRE A INSTANCE $( echo ${DB} | tr 'a-z' 'A-Z')"  >> $TEMPFILE_OUTPUT
  echo "************************************************************************************" >> $TEMPFILE_OUTPUT
  echo "$SPACER" >> $TEMPFILE_OUTPUT

  export AUX_DBNAME="$( echo ${DB} | tr 'a-z' 'A-Z')"
  
  ##################################################
  # Chamada da funcao que verifica o Backup Full
  ##################################################

  ArqBkpConcluido="$DirChkBkp/Bkp_${AUX_DBNAME}_Concluido" # Arquivo de Backup Concluido
  ArqBkpUltExec="$DirChkBkp/Bkp_${AUX_DBNAME}_Ultima_Exec" # Arquivo da Ultima Execucao Backup
  ArqBkpAndamento="$DirChkBkp/Bkp_${AUX_DBNAME}_Andamento" # Arquivo de Backup em Andamento

  echo "Verificacoes Backup Online" >> $TEMPFILE_OUTPUT

  verifica_online

  echo "$SPACER" >> $TEMPFILE_OUTPUT
  echo "$SPACER" >> $TEMPFILE_OUTPUT

  ##################################################
  # Chamada da funcao que verifica os backups Intermediarios
  ##################################################
  
  echo "Verificacoes Backups Intermediarios" >> $TEMPFILE_OUTPUT
  verifica_Intermediario

  echo "$SPACER" >> $TEMPFILE_OUTPUT
  echo "$SPACER" >> $TEMPFILE_OUTPUT
  echo "$SPACER" >> $TEMPFILE_OUTPUT

done

#################################################################################################################
#  FIM DOS TESTES
#################################################################################################################

## End of completely new changes
echo "" >> $TEMPFILE_OUTPUT
echo "" >> $TEMPFILE_OUTPUT
echo "" >> $TEMPFILE_OUTPUT
echo "" >> $TEMPFILE_OUTPUT

$RM -f $TEMPFILE > /dev/null 2>&1

# Send status (lit. Summary arrange)

GeraStatusFinal

COLOR=$STATUS_GERAL

if [ $COLOR = "green" ]
then
  echo "Teste Oracle realizado em \"$ORACLE_SIDS\": OK
" > $TEMPFILE
else
  echo "Teste Oracle relalizado em \"$ORACLE_SIDS\": Problema(s) Encontrado(s)
" > $TEMPFILE
fi

export LINE=`$CAT $TEMPFILE $TEMPFILE_OUTPUT`

$RM -f $TEMPFILE $TEMPFILE_OUTPUT > /dev/null 2>&1


DT_Exec=`date '+%m/%d/%Y %H:%M:%S - '`

# Report the status to the BB server

$BB $BBDISP "status $MACHINE.${TEST} $COLOR $DT_Exec $LINE"
#echo "$BB $BBDISP \"status $MACHINE.${TEST} $COLOR $DT_Exec $LINE\""

/bin/cat /dev/null > /tmp/test.log

exit 0
